﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Xml;
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using Microsoft.Win32;

namespace Alumina
{
	// Token: 0x02000004 RID: 4
	[Nullable(0)]
	[NullableContext(1)]
	public partial class MainWindow : Window
	{
		// Token: 0x0600000E RID: 14
		[DllImport("cd57e4c171d6e8f5ea8b8f824a6a7316.dll", CallingConvention = 2, CharSet = CharSet.Unicode)]
		public static extern int isAttached();

		// Token: 0x0600000F RID: 15
		[DllImport("cd57e4c171d6e8f5ea8b8f824a6a7316.dll", CallingConvention = 2, CharSet = CharSet.Unicode)]
		public static extern bool inject();

		// Token: 0x06000010 RID: 16
		[DllImport("cd57e4c171d6e8f5ea8b8f824a6a7316.dll", CallingConvention = 2, CharSet = CharSet.Ansi)]
		public static extern void executeScript([MarshalAs(UnmanagedType.LPStr)] string source);

		// Token: 0x06000011 RID: 17 RVA: 0x000024D8 File Offset: 0x000006D8
		public MainWindow()
		{
			this.InitializeComponent();
			base.Loaded += this.Window_Loaded;
			this.filesCollection = new ObservableCollection<FileInfo>();
			this.filesListBox.ItemsSource = this.filesCollection;
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002524 File Offset: 0x00000724
		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
			string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin", "lua.xshd");
			bool flag = File.Exists(text);
			if (flag)
			{
				using (FileStream fileStream = new FileStream(text, FileMode.Open, FileAccess.Read))
				{
					using (XmlReader xmlReader = XmlReader.Create(fileStream))
					{
						this.textEditor.SyntaxHighlighting = HighlightingLoader.Load(xmlReader, HighlightingManager.Instance);
					}
				}
			}
			else
			{
				MessageBox.Show("lua.xshd file not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			this.scriptsFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");
			bool flag2 = !Directory.Exists(this.scriptsFolder);
			if (flag2)
			{
				MessageBox.Show("The scripts folder does not exist.", "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			else
			{
				IEnumerable<FileInfo> enumerable = from file in Directory.GetFiles(this.scriptsFolder, "*.*")
					where file.EndsWith(".txt") || file.EndsWith(".lua")
					select new FileInfo(file);
				this.filesListBox.ItemsSource = enumerable;
				this.filesListBox.DisplayMemberPath = "Name";
			}
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002694 File Offset: 0x00000894
		private void Window_MouseDown(object sender, MouseButtonEventArgs e)
		{
			bool flag = e.ChangedButton == MouseButton.Left;
			if (flag)
			{
				base.DragMove();
			}
		}

		// Token: 0x06000014 RID: 20 RVA: 0x000026B8 File Offset: 0x000008B8
		private void filesListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
			FileInfo fileInfo = this.filesListBox.SelectedItem as FileInfo;
			bool flag = fileInfo != null;
			if (flag)
			{
				string text = File.ReadAllText(fileInfo.FullName);
				this.textEditor.Text = text;
			}
		}

		// Token: 0x06000015 RID: 21 RVA: 0x000026FC File Offset: 0x000008FC
		private void Console_Click(object sender, RoutedEventArgs e)
		{
			Console console = new Console();
			console.Show();
		}

		// Token: 0x06000016 RID: 22 RVA: 0x00002717 File Offset: 0x00000917
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			this.textEditor.Text = "";
		}

		// Token: 0x06000017 RID: 23 RVA: 0x0000272C File Offset: 0x0000092C
		private void OpenFileButton_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
			openFileDialog.FilterIndex = 1;
			openFileDialog.Multiselect = false;
			bool? flag = openFileDialog.ShowDialog();
			bool flag2 = true;
			bool flag3 = (flag.GetValueOrDefault() == flag2) & (flag != null);
			if (flag3)
			{
				string fileName = openFileDialog.FileName;
				try
				{
					bool flag4 = fileName.EndsWith(".lua") || fileName.EndsWith(".txt");
					if (flag4)
					{
						string text = File.ReadAllText(fileName);
						this.textEditor.Text = text;
					}
					else
					{
						MessageBox.Show("Please select a Lua or text file.", "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error opening file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002814 File Offset: 0x00000A14
		private void SaveFileButton_Click(object sender, RoutedEventArgs e)
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog();
			saveFileDialog.Filter = "Lua Files (*.lua)|*.lua|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
			saveFileDialog.FilterIndex = 1;
			bool? flag = saveFileDialog.ShowDialog();
			bool flag2 = true;
			bool flag3 = (flag.GetValueOrDefault() == flag2) & (flag != null);
			if (flag3)
			{
				string fileName = saveFileDialog.FileName;
				try
				{
					File.WriteAllText(fileName, this.textEditor.Text);
					MessageBox.Show("File saved successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error saving file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		// Token: 0x06000019 RID: 25 RVA: 0x000028C4 File Offset: 0x00000AC4
		private void Discord_Click(object sender, RoutedEventArgs e)
		{
			string text = "https://discord.gg/alumina";
			try
			{
				Process.Start(new ProcessStartInfo(text)
				{
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error opening link: " + ex.Message);
			}
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00002920 File Offset: 0x00000B20
		private void Close_Click(object sender, RoutedEventArgs e)
		{
			base.Close();
		}

		// Token: 0x0600001B RID: 27 RVA: 0x0000292A File Offset: 0x00000B2A
		private void Minimize_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00002935 File Offset: 0x00000B35
		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			this.OverlayGrid.Visibility = Visibility.Visible;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00002945 File Offset: 0x00000B45
		private void Button_Click_2(object sender, RoutedEventArgs e)
		{
			this.OverlayGrid.Visibility = Visibility.Collapsed;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002955 File Offset: 0x00000B55
		private void Button_Click_3(object sender, RoutedEventArgs e)
		{
			MainWindow.executeScript(this.textEditor.Text);
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002969 File Offset: 0x00000B69
		private void Button_Click_4(object sender, RoutedEventArgs e)
		{
			MainWindow.inject();
		}

		// Token: 0x04000006 RID: 6
		private ObservableCollection<FileInfo> filesCollection;

		// Token: 0x04000007 RID: 7
		private string scriptsFolder;
	}
}
