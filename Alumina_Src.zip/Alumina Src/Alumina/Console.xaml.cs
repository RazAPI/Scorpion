﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

namespace Alumina
{
	// Token: 0x02000003 RID: 3
	public partial class Console : Window
	{
		// Token: 0x06000004 RID: 4 RVA: 0x000020C3 File Offset: 0x000002C3
		public Console()
		{
			this.InitializeComponent();
			this.InitializeIronPython();
			this.DisplayHelp();
		}

		// Token: 0x06000005 RID: 5 RVA: 0x000020E2 File Offset: 0x000002E2
		private void InitializeIronPython()
		{
			this.engine = Python.CreateEngine();
		}

		// Token: 0x06000006 RID: 6 RVA: 0x000020F0 File Offset: 0x000002F0
		[NullableContext(1)]
		private void CommandTextBox_KeyDown(object sender, KeyEventArgs e)
		{
			bool flag = e.Key == Key.Return;
			if (flag)
			{
				string text = this.CommandTextBox.Text;
				string text2 = DateTime.Now.ToString("HH:mm:ss");
				TextBlock consoleTextBlock = this.ConsoleTextBlock;
				consoleTextBlock.Text = string.Concat(new string[] { consoleTextBlock.Text, text2, " ", text, "\n" });
				bool flag2 = !string.IsNullOrWhiteSpace(text);
				if (flag2)
				{
					bool flag3 = text.ToLower() == "clear";
					if (flag3)
					{
						this.ClearConsole();
					}
					else
					{
						bool flag4 = text.ToLower() == "terraria";
						if (flag4)
						{
							this.ExecuteTerrariaCommand();
						}
						else
						{
							this.ExecutePythonCommand(text);
						}
					}
				}
				this.CommandTextBox.Text = string.Empty;
				this.DisplayHelp();
			}
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000021E1 File Offset: 0x000003E1
		private void ClearConsole()
		{
			this.ConsoleTextBlock.Text = string.Empty;
		}

		// Token: 0x06000008 RID: 8 RVA: 0x000021F8 File Offset: 0x000003F8
		private void ExecuteTerrariaCommand()
		{
			try
			{
				string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin", "Terraria.py");
				ScriptScope scriptScope = this.engine.CreateScope();
				ScriptSource scriptSource = this.engine.CreateScriptSourceFromFile(text);
				scriptSource.Execute(scriptScope);
				Func<object> variable = scriptScope.GetVariable<Func<object>>("terraria_command");
				object obj = variable();
				bool flag = obj != null;
				if (flag)
				{
					TextBlock consoleTextBlock = this.ConsoleTextBlock;
					string text2 = consoleTextBlock.Text;
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
					defaultInterpolatedStringHandler.AppendFormatted<object>(obj);
					defaultInterpolatedStringHandler.AppendLiteral("\n");
					consoleTextBlock.Text = text2 + defaultInterpolatedStringHandler.ToStringAndClear();
				}
			}
			catch (Exception ex)
			{
				TextBlock consoleTextBlock2 = this.ConsoleTextBlock;
				consoleTextBlock2.Text = consoleTextBlock2.Text + "Error: " + ex.Message + "\n";
			}
		}

		// Token: 0x06000009 RID: 9 RVA: 0x000022E4 File Offset: 0x000004E4
		[NullableContext(1)]
		private void ExecutePythonCommand(string command)
		{
			try
			{
				string text = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin", "Terraria.py");
				ScriptScope scriptScope = this.engine.CreateScope();
				ScriptSource scriptSource = this.engine.CreateScriptSourceFromFile(text);
				scriptSource.Execute(scriptScope);
				Func<object> variable = scriptScope.GetVariable<Func<object>>("hello_world");
				object obj = variable();
				bool flag = obj != null;
				if (flag)
				{
					TextBlock consoleTextBlock = this.ConsoleTextBlock;
					string text2 = consoleTextBlock.Text;
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
					defaultInterpolatedStringHandler.AppendFormatted<object>(obj);
					defaultInterpolatedStringHandler.AppendLiteral("\n");
					consoleTextBlock.Text = text2 + defaultInterpolatedStringHandler.ToStringAndClear();
				}
			}
			catch (Exception ex)
			{
				TextBlock consoleTextBlock2 = this.ConsoleTextBlock;
				consoleTextBlock2.Text = consoleTextBlock2.Text + "Error: " + ex.Message + "\n";
			}
		}

		// Token: 0x0600000A RID: 10 RVA: 0x000023D0 File Offset: 0x000005D0
		private void DisplayHelp()
		{
			TextBlock consoleTextBlock = this.ConsoleTextBlock;
			consoleTextBlock.Text += "[1] - help\n[2] - clear\n[3] - terraria (this is where it will start the pysploit python console)\n";
		}

		// Token: 0x0600000B RID: 11 RVA: 0x000023F0 File Offset: 0x000005F0
		[NullableContext(1)]
		private void CommandTextBox_GotFocus(object sender, RoutedEventArgs e)
		{
			bool flag = this.CommandTextBox.Text == "Type in help to see commands";
			if (flag)
			{
				this.CommandTextBox.Text = string.Empty;
			}
		}

		// Token: 0x04000002 RID: 2
		[Nullable(1)]
		private ScriptEngine engine;
	}
}
